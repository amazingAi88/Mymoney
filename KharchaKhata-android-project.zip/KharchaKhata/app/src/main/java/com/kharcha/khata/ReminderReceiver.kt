package com.kharcha.khata

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val p = ctx.getSharedPreferences(Reminder.PREFS, Context.MODE_PRIVATE)
        if (p.getBoolean("on", false)) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("daily", ctx.getString(R.string.channel_name), NotificationManager.IMPORTANCE_DEFAULT)
            )
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(ctx, "daily")
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(p.getString("title", ctx.getString(R.string.app_name)))
                .setContentText(p.getString("body", ctx.getString(R.string.default_body)))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(1, n)
        }
        Reminder.schedule(ctx) // अगले दिन के लिए दोबारा लगाएँ
    }
}
